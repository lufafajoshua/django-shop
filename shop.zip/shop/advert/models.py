from django.db import models
#Also enable buying of products or accessing services
    # class Company(models.Model):
    #     name =
    #     address
    #     location
    #     products#This can also represent the services one company has many products and many products belong to a sigle company
    #     contact = #telephone contact

    # class Service(models.Model):
    #     name =
    #     provider #One service can have many providers
    #     description
    #     charges