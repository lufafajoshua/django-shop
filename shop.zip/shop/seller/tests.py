import datetime
from datetime import time

now = datetime.datetime.now()
print(now)

print(now.date())

