from django.contrib import admin
from .models import Profile, UserAgent

admin.site.register(Profile)
admin.site.register(UserAgent)