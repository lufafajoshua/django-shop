from django.apps import AppConfig


class DjangoChatterConfig(AppConfig):
    name = 'django_chatter'
